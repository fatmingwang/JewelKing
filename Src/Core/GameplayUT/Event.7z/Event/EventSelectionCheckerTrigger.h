#ifndef _EVENT_SELECTUIN_CHECKER_TRIGGER_H_
#define _EVENT_SELECTUIN_CHECKER_TRIGGER_H_

#include "EventBase.h"
#include "../../AllCoreInclude.h"
namespace FATMING_CORE
{
	//ButtonResult will get from name of pressed buttons
	//<cEventSelectionCheckerTrigger Name="79979" ButtonSelectionType="Repeat" StayAtLastSelect="0" ClickCount="5" HintPos="230,560" CompareResultVariable="VendorPassword" OutputResultVariable="InputPassword" KeepDoingUntilSameResult="1"  >
	//<cEventSelectionCheckerTrigger Name="79979" ButtonSelectionType="One" StayAtLastSelect="0" HintPos="" CompareResultVariable="" OutputResultVariable="79979" >
	//	<cEventButton Name="1" Text="���@" BGColor="1,0,0.5,1" Pos="260,200,0" KeyData="C" />
	//	<cEventButton Name="2" Text="���G" BGColor="1,0,0.5,1" Pos="260,300,0" KeyData="V" />
	//	<cEventButton Name="3" Text="���T" BGColor="1,0,0.5,1" Pos="260,400,0" KeyData="B" />
	//	<cEventButton Name="4" Text="���|4" BGColor="1,0,0.5,1" Pos="260,500,0" KeyData="N" />
	//	<cEventButton Name="5" Text="����5" BGColor="1,0,0.5,1" Pos="260,600,0" KeyData="M" />
	//	<cEventButton Name="6" Text="��`" BGColor="1,0,0.5,1" Pos="260,700,0" KeyData="L" />
	//	<cEventButton Name="7" Text="��u" BGColor="1,0,0.5,1" Pos="260,800,0" KeyData="I" />
	//	<cEventButton Name="8" Text="��" BGColor="1,0,0.5,1" Pos="260,900,0" KeyData="S" />
	//	<cEventButton Name="9" Text="�۰���" BGColor="1,0,0.5,1" Pos="260,900,0" KeyData="A" />
	//</cEventSelectionCheckerTrigger>
	class	cEventSelectionCheckerTrigger:public cEventMultiButton
	{
		//the final result to compare with what button u have pressed
		cEventVariable*		m_pCompareResultVariable;
		cEventVariable*		m_pOutputResultVariable;
		//if input result is not match it will keep dogint this event
		bool				m_bKeepDoingUntilSameResult;
		bool				m_bShowHint;
		Vector2				m_vHintPos;
		virtual	void		InternalUpdate(float e_fElpasedTime);
		virtual	void		InternalRender();
	public:
		DEFINE_TYPE_INFO();
		cEventSelectionCheckerTrigger(TiXmlElement*e_pTiXmlElement);
		//cEventMultiButton(eButtonSelectionType e_eButtonSelectionType);
		cEventSelectionCheckerTrigger(cEventSelectionCheckerTrigger*e_pEventSelectionCheckerTrigger);
		EVENT_CLONE_DEFINE(cEventSelectionCheckerTrigger);
		~cEventSelectionCheckerTrigger();
		virtual	TiXmlElement*		ToTiXmlElement();
	};
}
//end namespace FATMING_CORE
#endif