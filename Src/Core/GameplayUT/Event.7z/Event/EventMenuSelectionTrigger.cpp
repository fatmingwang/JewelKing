#include "../../stdafx.h"
#include "EventMenuSelectionActiver.h"

namespace FATMING_CORE
{


}