#ifndef _EVENT_ACTIVER_PARSER_H_
#define _EVENT_ACTIVER_PARSER_H_

#include "EventValueChangerActiver.h"

namespace   FATMING_CORE
{
	cEventBase*	GetActiverEvent(TiXmlElement*e_pTiXmlElement);
//end namespace   FATMING_CORE
}
#endif